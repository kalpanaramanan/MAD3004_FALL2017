//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func add(){
    print("I am in User Defined Function");
}

add();

func welcome(name:String,age:Int){
    print ("Hello, \(name) your age is \(age)");
}

welcome(name:"Kalpana Ramanan",age:27);

func sum(a:Int,b:Int){
    let c = a + b ;
    print("Sum of two values is : \(c)");
}
sum(a:10,b:15);
var a = 100 , b = 200 ;
sum(a:a,b:b);


func subtract(a:Int,_ b:Int){
    let c = a - b ;
    print("Subtract of two values is : \(c)");
}
subtract(a:a,b);

func multiple(a:Int,b:Int) -> Int
{
    let c = a * b ;
    print("Multiplication of two values is : \(c)");
    return c;
}
var c = multiple(a:a,b:b);
print (" FUNCTON WITH RETURN TYPE : \(c)");


func swapTwoNumber(a:Int,b:Int) -> (Int,Int)
{
    return (b,a);
}
(a,b) = swapTwoNumber(a: 10, b: 20) // SWAP TWO NUMBERS
print (a,b);


func swapTwoNumbers(a:Int,b:Int) -> (Int,Int)
{
    return (b,a);
}
(_,_) = swapTwoNumbers(a: 10, b: 20) // SWAP TWO NUMBERS
print (a,b);
(_,c) = swapTwoNumbers(a: 10, b: 20) // SWAP TWO NUMBERS
print (c);


func swapTwoNumberWithDouble(aa: inout Double,bb: inout Double) -> (Double,Double)
{
    let temp = aa;
    aa = bb;
    bb = temp;
    return (aa,bb);
}
var x = 8.0 , y = 9.0;
(x,y) = swapTwoNumberWithDouble(aa: &x, bb: &y) // SWAP TWO NUMBERS
print (x,y);


func displayArray(){
    let  aArray: [Int] = [1, 2,3];
    for i in aArray {
        print ("Value of i : ",i);
    }
}
displayArray();

func displayArrays(aArray: [Int] ){
    for i in aArray {
        print ("Value of i : ",i);
    }
}
displayArrays(aArray: [6,7,8]);

func simpleInterest(amount:Double,noOfYears:Double,rate:Double = 5.0) -> Double
{
    let si = ((amount * rate) * noOfYears) / 100 ;
    return si;
}

print(simpleInterest(amount: 100, noOfYears: 5));
print(simpleInterest(amount: 200, noOfYears: 50,rate: 45));

func simpleInterest_1(amount:Double,_ noOfYears:Double = 5.0,rate:Double ) -> Double
{
    let si = ((amount * rate) * noOfYears) / 100 ;
    return si;
}

print(simpleInterest_1(amount: 100, rate: 5));
print(simpleInterest_1(amount: 100, 10,rate: 5));

func displayArray_1(aArray: Int...,bArraay: Int){
    for i in aArray {
        print ("Value of i : ",i , "Value of b array \(b)");
    }
}
displayArray_1(aArray: 6,7,8,bArraay:09);
var arr = [1,2,3,4,5];
//displayArray_1(aArray: arr,bArraay:09);


var arr1 = [1,2,3,4,5];
var arr2 = [6,7,8,9,10];
func addArray(numberArray:[Int]...) -> [Int]{
    var k = [Int]();
    if (arr1.count == arr2.count){
    for i in  0..<arr1.count{
        k.append(arr1[i] * arr2[i]);
    }
    //print(k)
    }else{
        print("Arr1 and Arr2 SIZE is not same ");
    }
    return k;
}
var arr3 = addArray(numberArray:arr1,arr2);
print(arr3);
addArray(numberArray:arr1,arr2);


var stringWord = "1 12 15 16 50 ";
var doubleArray = stringWord.split(separator: " ");
print(doubleArray);
var result = [Int]();
for i in doubleArray{
    result.append(Int.init(i)!);
}
print(result);



func booleanStringCheck(s1:String,s2:String) -> Bool {
    return s1 > s2 ;
}

print (booleanStringCheck(s1:"10", s2: "6"))


var str3 = ["Kalpana","Ramanan","Sai","Praveen"];
print(str3);

str3 = str3.sorted { (s1:String, s2:String) -> Bool in
    return s1 > s2 ;
}
print(str3);

str3 = str3.sorted { (s1:String, s2:String) -> Bool in
    return s1 < s2 ;
}
print(str3);


var sum =  {(s1:Int, s2:Int) -> Int in
    return s1 + s2 ;
}

print(sum(20,50));

