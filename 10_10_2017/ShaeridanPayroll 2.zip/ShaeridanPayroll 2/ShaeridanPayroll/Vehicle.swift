public class Vehicle: IPrintable {
    
    private var _make: String?
    var make: String {
        set { _make = newValue
        }
        get { return _make! }
    }
    
    private var _model: String?
    var model: String {
        set { _model = newValue
        }
        get { return _model! }
    }
    
    init() {
        make = ""
        model = ""
    }
    
    init(pMake: String, pModel: String) {
        make = pMake
        model = pModel
    }
    
    func printMyData() {
        print("Make : \(self.make)")
        print("Model : \(self.model)")
    }
}
