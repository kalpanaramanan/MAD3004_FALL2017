//
//  FixedBasedPartTime.swift
//  ShaeridanPayroll
//
//  Created by Kirti Parghi on 10/4/17.
//  Copyright © 2017 Marc Bueno Inc. All rights reserved.
//

import Foundation

class FixedBasedPartTime : PartTime {
 
    private var _fixedAmount: Double?
    var fixedAmount: Double {
        set { _fixedAmount = newValue
        }
        get { return _fixedAmount! }
    }

    override init() {
        super.init()
        fixedAmount = 0
    }
    
    init(ppName: String, ppAge: Int, pHourlyRate: Int, pNumberHoursWorked: Int, ppV: Vehicle, fixedAmount:Double) {
        super.init(ppName: ppName, ppAge: ppAge, pHourlyRate: pHourlyRate, pNumberHoursWorked: pNumberHoursWorked, ppV: ppV)
        self.fixedAmount = fixedAmount
    }
    
    override func printMyData() {
        super.printMyData()
        print("Employee is PartTime / FixedAmt")
        print ("Rate: \(hourlyRate)")
        print ("Hours Worked: \(numberHoursWorked)")
        print("Earnings: \(self.calcEarnings())")
    }
    
    //CALCULATE EARNINGS
    override func calcEarnings() -> Double {
        return Double(hourlyRate * numberHoursWorked) + fixedAmount
    }
}
