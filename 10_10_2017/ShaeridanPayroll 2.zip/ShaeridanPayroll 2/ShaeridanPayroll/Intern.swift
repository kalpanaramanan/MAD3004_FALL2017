public class Intern : Employee {
    
    private var _schoolName: String?
    var schoolName: String {
        set { _schoolName = newValue
        }
        get { return _schoolName! }
    }
    
    override init() {
        super.init()
        schoolName = ""
    }
    
    init(pName: String, pAge: Int, pSchool: String) {
        super.init(pName, pAge)
        schoolName = pSchool
    }
    
    init(pName: String, pAge: Int, pSchool: String, ppV: Vehicle?) {
        super.init(pName, pAge, ppV)
        schoolName = pSchool        
    }

    override func printMyData() {
        super.printMyData()
        print("Employee is Intern")
        print ("School Name: \(schoolName)")
    }
}
