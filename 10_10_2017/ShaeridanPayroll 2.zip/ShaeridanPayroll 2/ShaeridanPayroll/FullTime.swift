public class FullTime : Employee {
    
    private var _salary: Int?
    var salary: Int {
        set { _salary = newValue
        }
        get { return _salary! }
    }

    private var _bonus: Int?
    var bonus: Int {
        set { _bonus = newValue
        }
        get { return _bonus! }
    }

    override init() {
        super.init();
        salary = 0
        bonus = 0
    }
    
    init(ppName: String, ppAge: Int, pSalary: Int, pBonus: Int) {
        super.init(ppName, ppAge)
        salary = pSalary
        bonus = pBonus
    }
    
    init(ppName: String, ppAge: Int, pSalary: Int, pBonus: Int, ppV: Vehicle) {
        super.init(ppName, ppAge, ppV)
        salary = pSalary
        bonus = pBonus
    }

    
    override func calcEarnings() -> Double {
        return Double(salary + bonus)
    }
    
    override func printMyData() {
        super.printMyData()
        print ("Salary: \(salary)")
        print ("Bonus: \(bonus)")
    }
    
    
    
    
}
