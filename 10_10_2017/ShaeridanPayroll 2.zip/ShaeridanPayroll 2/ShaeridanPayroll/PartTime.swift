

public class PartTime: Employee {
    
    private var _hourlyRate: Int?
    var hourlyRate: Int {
        set { _hourlyRate = newValue
        }
        get { return _hourlyRate! }
    }

    private var _numberHoursWorked: Int?
    var numberHoursWorked: Int {
        set { _numberHoursWorked = newValue
        }
        get { return _numberHoursWorked! }
    }

    override init() {
        super.init()
        hourlyRate = 0
        numberHoursWorked = 0
    }
    
    init(ppName: String, ppAge: Int, pHourlyRate: Int, pNumberHoursWorked: Int) {
        super.init(ppName, ppAge)
        hourlyRate = pHourlyRate
        numberHoursWorked = pNumberHoursWorked
    }
    
    init(ppName: String, ppAge: Int, pHourlyRate: Int, pNumberHoursWorked: Int, ppV: Vehicle) {
        super.init(ppName, ppAge, ppV)
        hourlyRate = pHourlyRate
        numberHoursWorked = pNumberHoursWorked        
    }
    
    
    override func calcEarnings() -> Double {
        return Double(numberHoursWorked * hourlyRate)
    }
    
    override func printMyData() {
        super.printMyData()
    }
    
    
    
    
}
