//
//  File.swift
//  ShaeridanPayroll
//
//  Created by Kirti Parghi on 10/4/17.
//  Copyright © 2017 Marc Bueno Inc. All rights reserved.
//

import Foundation

class Car : Vehicle {
    
    private var _speed: Double?
    var speed: Double {
        set { _speed = newValue
        }
        get { return _speed! }
    }

    private var _maxSpeed: Double?
    var maxSpeed: Double {
        set { _maxSpeed = newValue
        }
        get { return _maxSpeed! }
    }
    
    private var _licensePlate: String?
    var licensePlate: String {
        set { _licensePlate = newValue
        }
        get { return _licensePlate! }
    }
    
    override init() {
        super.init()
        speed = 0
        maxSpeed = 0
        licensePlate = ""
    }
    
    init(make:String, model:String, speed:Double, maxSpeed:Double, licensePlate:String) {
        super.init(pMake: make, pModel: model)
        self.speed = speed
        self.maxSpeed = maxSpeed
        self.licensePlate = licensePlate
    }
    
    override func printMyData() {
        print("Car details...")
    }
    
    public func getClassType() -> String {
        return "Car"
    }
}
