//
//  Singleton.swift
//  ShaeridanPayroll
//
//  Created by Kirti Parghi on 10/5/17.
//  Copyright © 2017 Marc Bueno Inc. All rights reserved.
//

import Foundation

class Singleton {
    static let sharedInstance = Singleton()
    
    private init() {
        
    }
    
    //Creating Object of Car for Employee "John"
    var objCommissionBasedPartTime = CommissionBasedPartTime(ppName: "John", ppAge: 26, pHourlyRate: 20, pNumberHoursWorked: 100, ppV: Car(make: "TOYOTO", model: "PRIUS", speed: 50, maxSpeed: 70, licensePlate: "A1234"), commissionPerc: 40)

    var objFixedBasedPartTime = FixedBasedPartTime(ppName: "Cindy", ppAge: 30, pHourlyRate: 25, pNumberHoursWorked: 40, ppV: Motorcycle(make: "SKODA", model: "FABIA", color: "RED", engineState: true), fixedAmount:5000)

    var objIntern = Intern(pName: "Matthew", pAge: 22, pSchool: "Sheridan College", ppV: nil)    
}
