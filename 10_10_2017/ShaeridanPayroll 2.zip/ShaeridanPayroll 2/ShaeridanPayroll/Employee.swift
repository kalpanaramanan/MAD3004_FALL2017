public class Employee : IPrintable {
    
    private var _name: String?
    var name: String {
        set { _name = newValue
        }
        get { return _name! }
    }
    
    private var _age: Int?
    var age: Int {
        set { _age = newValue
        }
        get { return _age! }
    }
    
    private var _v: Vehicle?
    var v: Vehicle {
        set {
            _v = newValue
        }
        get { return _v! }
    }
    
    //CONFIRMS PROTOCOL
    func printMyData() {
        print("Name: \(self.name)")
        print("Year of Birth: \(self.calcBirthYear())")
        if _v is Car {
            print("Employee has a Car")
            print("Make : \(_v!.make)")
            print("Plate : \(_v!.model)")
        }
        else if _v is Motorcycle {
            print("Employee has a Motorcycle")
            print("Make : \(_v!.make)")
            print("Plate : \(_v!.model)")
        }
        else {
            print("Employee has no Vehicle registered")
        }        
    }
    
//    func setAge(pAge: Int) {
//        if pAge >= 0 {
//           age = pAge
//        } else {
//            age = 0
//        }
//    }
//    
//    func getAge() -> Int {
//        return self.age
//    }
    
    init() {
        name = ""
        age = 0
        v = Vehicle()
    }
    
    init (_ pName: String,_ pAge: Int) {
        name = pName
        age = pAge
        v = Vehicle()
    }
    
    init (_ pName: String,_ pAge: Int, _ pV: Vehicle?) {
        name = pName
        age = pAge
        if let obj = pV {
            v = (pV)!
        }
        else {
            v = Vehicle()
        }
        
    }
    
    
    func calcBirthYear() -> Int {
        return (2017 - self.age)
    }
    
    func calcEarnings() -> Double {
        return 1000.00
    }
}
