//
//  CommissionBasedPartTime.swift
//  ShaeridanPayroll
//
//  Created by Kirti Parghi on 10/4/17.
//  Copyright © 2017 Marc Bueno Inc. All rights reserved.
//

import Foundation

class CommissionBasedPartTime : PartTime {
    
    private var _commissionPerc: Double?
    var commissionPerc: Double {
        set { _commissionPerc = newValue
        }
        get { return _commissionPerc! }
    }

    override init() {
        super.init()
        commissionPerc = 0
    }
    
    init(ppName: String, ppAge: Int, pHourlyRate: Int, pNumberHoursWorked: Int, ppV: Vehicle, commissionPerc:Double) {
        super.init(ppName: ppName, ppAge: ppAge, pHourlyRate: pHourlyRate, pNumberHoursWorked: pNumberHoursWorked, ppV: ppV)
        self.commissionPerc = commissionPerc
    }
    
    override func printMyData() {
        super.printMyData()
        print("Employee is PartTime / Comissioned")
        print("Rate: \(hourlyRate)")
        print("Hours Worked: \(numberHoursWorked)")
        print("Commission: \(_commissionPerc!)%")
        print("Earnings: \(self.calcEarnings())")
    }
    
    //CALCULATE EARNINGS
    override func calcEarnings() -> Double {
        return Double(hourlyRate * numberHoursWorked) + commissionPerc
    }
}
