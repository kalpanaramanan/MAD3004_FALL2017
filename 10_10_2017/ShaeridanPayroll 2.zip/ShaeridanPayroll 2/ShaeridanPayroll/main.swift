
/*****
 
 ABSTRACT CLASS : EMPLOYEE, VEHICLE,PARTTIME
 ***/


//PROTOCOL : IPRITABLE
protocol IPrintable {
    func printMyData()
}
/*
var aEmp = [Employee]()


// create fulltime
var ft1 = FullTime() // default constructor
ft1.name = "Janet"
ft1.age = 20
ft1.salary = 50000
ft1.bonus = 2000

var vRef = Vehicle(pMake: "Ferrari",pModel: "458")
ft1.v = vRef

aEmp.append(ft1)

// create parttime
var pt1 : PartTime

vRef = Vehicle(pMake: "Porsche", pModel: "Carrera")

pt1 = PartTime(ppName: "Matthew", ppAge: 10, pHourlyRate: 100, pNumberHoursWorked: 2, ppV: vRef)

aEmp.append(pt1)

//create intern

vRef = Vehicle(pMake: "BMW", pModel: "X6")
var it1 = Intern(pName: "Loonie", pAge: 15, pSchool: "WoofCenter", ppV: vRef)

aEmp.append(it1)

//create intern


var it2 = Intern(pName: "Toonie", pAge: 15, pSchool: "JKWoofCenter")
aEmp.append(it2)



// calculate payroll

var totalPR : Double = 0.0
var e : Employee

for i in 0..<aEmp.count {
    
    e = aEmp[i]
    var earn = e.calcEarnings()
    
//    print ("Name: \(e.name)")
//    print ("Age: \(e.age)")
    e.printMyData()
    // display vehicle
    if (e.v == nil) {
        print ("** Employee has not registered any vehicle ***")
    } else {
        print ("*** Employe has a Vehicle")
        print ("Make: \(e.v.make)")
        print ("Model: \(e.v.model)")
    }
    print ("Birth Year: " + String(e.calcBirthYear()))
    print ("Earnings: \(earn)")
    print ("**********************")
    
    totalPR = totalPR + earn
}

print ("TOTAL PAYROLL: \(totalPR)")
*/

/************** SAMPLE OUTPUT
 Name: John
 Year of Birth: 1997
 Employee has a Motorcycle
 Make
 Plate
 Additional Attribute 1
 Additional Attribute 2
 Employee is PartTime / Commissioned
 Rate: 30
 HoursWorked: 10
 Commission: 20%
 Earnings: 360.00 (300 + 20% of 300)
 ************/

// DON'T CREATE OBJECT OF EMPLOYEE , VEHICLE , PARTTIME

//Creating Object of Car for Employee "John"
//var objCar = Car(make: "TOYOTO", model: "PRIUS", speed: 50, maxSpeed: 70, licensePlate: "A1234")
//
//var objCommissionBasedPartTime = CommissionBasedPartTime(ppName: "John", ppAge: 26, pHourlyRate: 20, pNumberHoursWorked: 100, ppV: objCar, commissionPerc: 40)

Singleton.sharedInstance.objCommissionBasedPartTime.printMyData()

print("****************************************************************************************************************************")

//Creating another object
//Creating Object of Car for Employee "Cindy"
//var objMotorcycle = Motorcycle(make: "SKODA", model: "FABIA", color: "RED", engineState: true)
//
//var objFixedBasedPartTime = FixedBasedPartTime(ppName: "Cindy", ppAge: 30, pHourlyRate: 25, pNumberHoursWorked: 40, ppV: objMotorcycle, fixedAmount:5000)
Singleton.sharedInstance.objFixedBasedPartTime.printMyData()


print("****************************************************************************************************************************")
/***
 Name: Matthew
 Year of Birth: 1995
 Employee has no Vehicle registered
 Employee is Intern
 SchoolName: Sheridan College
 Earnings: 1,000
 */

//var objIntern = Intern(pName: "Matthew", pAge: 22, pSchool: "Sheridan College", ppV: nil)
Singleton.sharedInstance.objIntern.printMyData()

print("****************************************************************************************************************************")
print("TOTAL PAYROLL: \(Singleton.sharedInstance.objCommissionBasedPartTime.calcEarnings()+Singleton.sharedInstance.objFixedBasedPartTime.calcEarnings())")

