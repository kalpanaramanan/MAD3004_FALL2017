//
//  Motorcycle.swift
//  ShaeridanPayroll
//
//  Created by Kirti Parghi on 10/4/17.
//  Copyright © 2017 Marc Bueno Inc. All rights reserved.
//

import Foundation

class Motorcycle : Vehicle {
    
    private var _color: String?
    var color: String {
        set { _color = newValue
        }
        get { return _color! }
    }

    private var _engineState: Bool?
    var engineState: Bool {
        set { _engineState = newValue
        }
        get { return _engineState! }
    }

    override init() {
        super.init()
        color = ""
        engineState = false
    }
    
    init(make:String, model:String, color:String, engineState:Bool) {
        super.init(pMake: make, pModel: model)
        self.color = color
        self.engineState = engineState
    }
    
    override func printMyData() {
        print("Motorcycle details...")
    }
    
    //FUNCTION START ENGINE
    func startEngine() {
        if engineState == true {
            print("The engine is already on.")
        }
        else {
            self.engineState = true
            print("The engine is now on.")
        }
    }
    
    public func getClassType() -> String {
        return "Motorcycle"
    }
}
