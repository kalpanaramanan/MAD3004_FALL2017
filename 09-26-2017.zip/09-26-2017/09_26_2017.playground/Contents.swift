//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground";
print(str);

var a = 10,b = 2;
//a++
//var a4 = a+=1;
//print(a4);
//var c = 5 + b * (a+=1) + (a+=1) ;
print ("value of a: \(a),Value of b: \(b)");

// DECLEARATING A TUPLES
var x = (10,20,30);
print(x.0);
print(x.1);
print(x.2);

//COPY VALUE FROM ONE TUPLE TO ANOTHER
var y = (100,x.1,x.2);
print(y.0);
print(y.1);
print(y.2);

var (a1,a2,a3) = y ;
print(a1);
print(a2);
print(a3);

var (b1, _, b2) = x
print(b1);

//DECELRAING THE ARRAY
var aArray = [10,20,30,40,50];
print(aArray[3]);


//USE METHODS TO ADD VALUES
var bArray = [Int]();
bArray.append(100);
print(bArray[0]);
print("Size: \(bArray.count)");
bArray[0] = 500;
print(bArray[0]);
print("Size: \(bArray.count)");

//USE ANY TO ADD VALUES
var cArray = [Any]();
cArray.append(100);
cArray.append("Kalpana");
print(cArray[0]);
print(cArray[1]);
print("Size: \(cArray.count)");
cArray[0] = 500;
print(cArray[0]);
print("Size: \(cArray.count)");

//USING ARRAY IN FOR LOOP
var xArray = aArray[0...4];

print("data ",xArray[0]); // SLICE OF AN ARRAY BUT REMEBER xArray IS NOT THE SUBARRAY

for iArray in xArray{
    print (iArray);
}

xArray[0] = 2000;
print(xArray[0]);

//CREATING an ARRAY with A DEFAULT VALUE
var z = Array(repeating: 0.0,count:3)
for t in z{
    print(t);
}

// STRING ARRAY AND FOR-EACH WITH (KEY,VALUE)
var shoppingList : [String] = ["Eggs","Milk"]
for(index,value) in shoppingList.enumerated(){
    print("Item \(index) : \(value)");
}


//Cobine TWO ARRAY
var xxArray = aArray + bArray ;
print(xxArray[0]);

let apples = xxArray.removeLast();
print(apples);
print(xArray.count)


let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

print(oddDigits.union(evenDigits).sorted())
// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print(oddDigits.intersection(evenDigits).sorted())
// []
print(oddDigits.subtracting(singleDigitPrimeNumbers).sorted())
// [1, 9]
print(oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted())
// [1, 2, 9]

//DECLEARING SET IN SWIFT
var favoriteGenres: Set<String> = ["Rock","Classical","Hip Hop","Rock"];
print(favoriteGenres);
print(favoriteGenres[favoriteGenres.index(favoriteGenres.startIndex, offsetBy: 0)] );

print("I have \(favoriteGenres.count) favorite music genres.");

if favoriteGenres.isEmpty {
    print("As far as music goes, I'm not picky.")
} else {
    print("I have particular music preferences.")
}
// Prints "I have particular music preferences."

//DICTONARIES
var d1 : Dictionary<String,String> = ["India":"Hindi","Canada":"English"]
print(d1);
print(d1.description);
print(d1["India"]!);

d1["china"] = "Mandarin";

for(k,v) in d1{
    print("\(k) --> \(v)");
}

var d2 = ["India":"Hindi","Canada":"English"];

for(k,v) in d2{
    print("\(k) --> \(v)");
}

var d3 :Dictionary<String,Any> = ["India":Date(),"Canada":Date()];
for(k,v) in d3{
    print("\(k) --> \(v)");
}

//GETTING AS A KEY, VALUE PAIR
var d4 = [String:AnyObject]();
d4["firstname"] = "Kalpana" as AnyObject;
d4["lastname"] = "Ramanan" as AnyObject;
d4["age"] = Int.init(32) as AnyObject;
d4["salary"] = nil;
d4["birthDate"] = NSDate() as AnyObject;

print(d4);

for(k,v) in d4{
    print("\(k) --> \(v)");
}

//GETTING AS A SINGLE OBJECT
for obj in  d4 {
    print( " \(obj.key ) ----. \(obj.value)")
}

//GETTING ONLY KEYS FROM DICTIONARY
var keyList = Array(d3.keys);
for v in keyList{
    print("KEY ---> \(v)");
}

//GETTING ONLY VALUES FROM DICTIONARY
var valueList = Array(d3.values)
for v in valueList{
     print("VALUE ---> \(v)");
}



//student id
// name -- firstname and last name
//adddress -- street,aprtno, city,province,country,postalcode
//bod -- dd,mm,yy


var studentName :Dictionary<String,Any> = [
    "FirstName ":"Kalpana",
    "LastName":"Ramanan"
];
var studentAddress :Dictionary<String,Any> = [
    "ApartmentNo":"10",
    "Street":"Plumbroom",
    "City":"Scarbrough",
    "Country":"Canada",
    "Z":"M1S3Z8"
];
var studentDOB :Dictionary<String,Any> = [
    "DD":27,
    "MM":05,
    "YYYY":1998
];

var studentDic :Dictionary<String,AnyObject> = [
        "StudentId":"C0715368" as AnyObject ,
        "StudentName":studentName as AnyObject,
        "StudentAddress":studentAddress as AnyObject,
        "StudentDOB":studentDOB as AnyObject,
];

print(studentDic);
























