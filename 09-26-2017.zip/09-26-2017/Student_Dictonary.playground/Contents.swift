//: Playground - noun: a place where people can play

import UIKit


//
//  Student_Dictonary.swift
//
//
//  Created by MacStudent on 2017-09-26.
//

import UIKit;


//student id
// name -- firstname and last name
//adddress -- street,aprtno, city,province,country,postalcode
//bod -- dd,mm,yy


var studentName :Dictionary<String,Any> = [
    "FirstName ":"Kalpana",
    "LastName":"Ramanan"
];
var studentAddress :Dictionary<String,Any> = [
    "ApartmentNo":"10",
    "Street":"Plumbroom",
    "City":"Scarbrough",
    "Country":"Canada",
    "Z":"M1S3Z8"
];
var studentDOB :Dictionary<String,Any> = [
    "DD":27,
    "MM":05,
    "YYYY":1998
];

var studentDic :Dictionary<String,AnyObject> = [
    "StudentId":"C0715368" as AnyObject ,
    "StudentName":studentName as AnyObject,
    "StudentAddress":studentAddress as AnyObject,
    "StudentDOB":studentDOB as AnyObject,
];

print(studentDic);


